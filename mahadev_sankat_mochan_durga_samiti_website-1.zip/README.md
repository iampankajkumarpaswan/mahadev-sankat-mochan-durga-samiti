# महादेव संकट मोचन दुर्गा समिति — Free Website

इस folder में `index.html` आपकी पूरी website है।

## Free में Live करने का तरीका
1. GitHub पर free account बनाएं।
2. New **Public repository** बनाएं।
3. `index.html` upload करें।
4. Repository → Settings → Pages → Deploy from branch → `main` → `/root` चुनें।
5. Save करें। कुछ मिनट में आपका free `github.io` website address मिल जाएगा।

बाद में इसी `index.html` में पूजा की तारीख, WhatsApp नंबर और photos जोड़ी जा सकती हैं।
